
<?php





$username = "postgres";
$password = "123456";
try {
    $conn = new PDO("pgsql:host=localhost;port=5432;dbname=hospital", $username, $password);
// set the PDO error mode to exception
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
echo "Connected successfully";
// echo 'HI';
echo '<pre>';
// print_r($_GET);
//var_dump($_GET);

} 

catch(PDOException $e) {
echo "Connection failed: " . $e->GETMessage();
}




$patient_id = $_GET['patient_id'];
$date_discharge= $_GET['date_discharge'];
$room_id=$_GET['room_id'];


  
    $query_1= $conn->prepare(   "INSERT INTO inpatient VALUES (?, ?, ?)");
    $query_1->execute([$patient_id,$date_discharge,$room_id]);


echo '<br>';
echo 'Your form has been submitted successfully';
echo '<a href="./index.php">Click here to go back to main page</a>';

?>



