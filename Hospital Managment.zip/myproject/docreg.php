<?php
$username = "postgres";
$password = "123456";
try {
    $conn = new PDO("pgsql:host=localhost;port=5432;dbname=hospital", $username, $password);
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Connected successfully";
    echo '<pre>';
} 
catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

$doctor_id = $_GET['doctor_id'];
$name = $_GET['name'];
$qualification = $_GET['qualification'];

try {
    $query_1 = $conn->prepare("INSERT INTO doctor VALUES (:doctor_id, :name, :qualification)");
    $query_1->bindParam(':doctor_id', $doctor_id);
    $query_1->bindParam(':name', $name);
    $query_1->bindParam(':qualification', $qualification);
    $query_1->execute();
    
    echo '<br>';
    echo 'Your form has been submitted successfully';
    echo '<a href="./index.php">Click here to go back to main page</a>';
}
catch(PDOException $e) {
    echo '<br>';
    echo 'Error: ' . $e->getMessage();
}
?>